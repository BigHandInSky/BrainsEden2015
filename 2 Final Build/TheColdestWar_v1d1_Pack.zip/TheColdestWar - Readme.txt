///// THE COLDEST WAR
By Team Bed:
- Peter 		/ Team Lead, Programming, 2D Art
- Will 		/ 3D/2D Art
- Russ 		/ Programming
- Robert 		/ Programming, Audio
- Dawid 		/ Programming, Audio

///// DETAILS
[Story]
In a universe where war has lead to the Earth being split in two:
Between the Blue OOSA and the red ROOSA.
War has halted, leading to a race into orbit.
This isn't just any war...this is...
THE COLDEST WAR.

[Installation instructions]
PC:
 - Run the EXE
Tablet:
 - Run the APK file and the game will install

///// CONTROLS
Controls can be rebinded in the Unity Launcher if controllers are desired.

PC:
 - Mouse over and click rocket icon to change rocket type
 - Red Player:
   - A/D - rotate turret
   - W - shoot rocket, hold to power up
 - Blue Player:
   - Left/Right arrow - Rotate turret
   - Up arrow - shoot rocket, hold to power up

Tablet:
 - Touch to shoot, aim
 - Rocket Type icon - touch to change rocket